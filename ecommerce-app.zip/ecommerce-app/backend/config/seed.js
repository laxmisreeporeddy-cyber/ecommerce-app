// Run with: npm run seed
// Populates the database with demo admin/user accounts and sample products.
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./db');
const User = require('../models/User');
const Product = require('../models/Product');
const Order = require('../models/Order');

const seed = async () => {
  await connectDB();

  console.log('Clearing existing data...');
  await Promise.all([User.deleteMany(), Product.deleteMany(), Order.deleteMany()]);

  console.log('Creating users...');
  const admin = await User.create({
    name: 'Admin User',
    email: 'admin@shop.com',
    password: 'admin123',
    role: 'admin',
  });

  const demoUser = await User.create({
    name: 'John Doe',
    email: 'user@shop.com',
    password: 'user123',
    role: 'user',
    address: { street: '123 Main St', city: 'New York', state: 'NY', zip: '10001', country: 'USA' },
  });

  console.log('Creating products...');
  const products = await Product.insertMany([
    {
      name: 'Wireless Headphones',
      description: 'Premium wireless headphones with active noise cancellation and 30-hour battery life.',
      price: 89.99,
      category: 'Electronics',
      stock: 15,
      imageUrl: '',
      createdBy: admin._id,
    },
    {
      name: 'Smart Watch',
      description: 'Feature-rich smartwatch with health monitoring, GPS, and 7-day battery life.',
      price: 249.99,
      category: 'Electronics',
      stock: 8,
      createdBy: admin._id,
    },
    {
      name: 'Running Shoes',
      description: 'Lightweight and responsive running shoes designed for daily training.',
      price: 129.99,
      category: 'Sports',
      stock: 22,
      createdBy: admin._id,
    },
    {
      name: 'Coffee Maker',
      description: 'Programmable 12-cup coffee maker with auto-clean feature.',
      price: 79.99,
      category: 'Home',
      stock: 3,
      createdBy: admin._id,
    },
    {
      name: 'JavaScript: The Complete Guide',
      description: 'Master modern JavaScript from fundamentals to advanced concepts, with 200+ exercises.',
      price: 39.99,
      category: 'Books',
      stock: 0,
      createdBy: admin._id,
    },
    {
      name: 'Yoga Mat',
      description: 'Eco-friendly non-slip yoga mat with alignment lines, 6mm thick.',
      price: 34.99,
      category: 'Sports',
      stock: 30,
      createdBy: admin._id,
    },
    {
      name: 'Cotton T-Shirt 3-Pack',
      description: 'Pack of 3 premium cotton t-shirts, breathable and durable.',
      price: 44.99,
      category: 'Clothing',
      stock: 18,
      createdBy: admin._id,
    },
    {
      name: 'LED Desk Lamp',
      description: 'Adjustable LED desk lamp with USB charging port and 5 brightness levels.',
      price: 55.99,
      category: 'Home',
      stock: 11,
      createdBy: admin._id,
    },
  ]);

  console.log('Creating a sample order...');
  await Order.create({
    user: demoUser._id,
    items: [
      {
        product: products[0]._id,
        name: products[0].name,
        quantity: 1,
        price: products[0].price,
      },
    ],
    shippingAddress: {
      fullName: 'John Doe',
      street: '123 Main St',
      city: 'New York',
      state: 'NY',
      zip: '10001',
      country: 'USA',
    },
    paymentMethod: 'card',
    itemsPrice: products[0].price,
    shippingPrice: 9.99,
    taxPrice: Number((products[0].price * 0.08).toFixed(2)),
    totalPrice: Number((products[0].price + 9.99 + products[0].price * 0.08).toFixed(2)),
    status: 'delivered',
    statusHistory: [{ status: 'pending' }, { status: 'processing' }, { status: 'shipped' }, { status: 'delivered' }],
  });

  console.log('Seed complete!');
  console.log('---------------------------------');
  console.log('Admin login: admin@shop.com / admin123');
  console.log('User login:  user@shop.com / user123');
  console.log('---------------------------------');

  await mongoose.connection.close();
  process.exit(0);
};

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
